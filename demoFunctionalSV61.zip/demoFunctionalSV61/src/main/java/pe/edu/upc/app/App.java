package pe.edu.upc.app;

import java.util.ArrayList;
import java.util.List;

import pe.edu.upc.interfaces.Operate;
import pe.edu.upc.interfaces.Suma;

public class App {

	public static void main(String[] args) {
		App app = new App();

		List<Integer> list = new ArrayList<Integer>();
		list.add(100);
		list.add(10);
		list.add(17);
		list.add(5);
		list.add(30);
		list.add(45);
	/*	for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
			
		}*/
		
		//list.forEach(x->System.out.println(x));
		
	/*	Operate op=new Suma();
		int rpta=op.operate(5, 9);
		System.out.println(rpta);*/
		
		Operate op1=(x,y)->x+y;
		//op1.operate(3, 5);
		System.out.println(op1.operate(3, 5));
		
		Operate op2=(x,y)->x*y;
		System.out.println(op2.operate(8, 9));
	}
}
