package pe.edu.upc.app;

import java.util.function.Consumer;

import pe.edu.upc.model.Product;

public class ConsumerApp {
	public void method1(){
		Consumer<String> print=x->System.out.println(x);
		print.accept("Arquitectura");
	}
	
	public void method2(){
		Consumer<Product> prueba=x->{
			x.setStatus(true);
			x.setName("Mouse");
			x.setPrice(950);
			x.setId(205);
		};
		
		Product p=new Product(105, "Impresora", 750, false);
		prueba.accept(p);
		System.out.println(p.isStatus()+"-"+p.getName()
		+"-"+p.getPrice()+"-"+p.getId());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConsumerApp app=new ConsumerApp();
		app.method1();
	}

}
