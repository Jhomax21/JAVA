package pe.edu.upc.app;

import java.util.function.Predicate;

import pe.edu.upc.model.Product;

public class PredicateApp {

	
	public void method1(){
		Predicate<Integer> checkNum=x->x>100;
		System.out.println(checkNum.test(22));
	}
	
	public void method2(){
		Predicate<String> checkString=s->s.equals("UPC");
		System.out.println(checkString.test("Arquitectura"));
	}
	//PREDICATE que verifique 
	//que el precio sea mayor a 1500 y el status sea true
	public void method3(){
		Product a=new Product(100,"TV",4500,false);
		Predicate<Product>checkProduct=p->p.getPrice()>1500 && p.isStatus()==true;
		System.out.println(checkProduct.test(a));
	}
	
	public static void main(String[] args) {
		PredicateApp app=new PredicateApp();
		
		//app.method1();
		//app.method2();
		app.method3();
	}

}
