package pe.edu.upc.interfaces;

public interface Operate {

	int operate(int x, int y);
}
