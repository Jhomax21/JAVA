package pe.edu.upc.interfaces;

public class Suma implements Operate{

	@Override
	public int operate(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

}
