package pe.edu.upc;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Taxi t =new  Taxi("ABC-110","BT","BT-100", 12589);
		
		t.mostrarTaxi();

	}

}
