package pe.edu.upc;

public class Taxi extends Vehiculo{
	private int nPermiso;

	public Taxi(String placa, String marca, String modelo, int nPermiso) {
		super(placa, marca, modelo);
		// TODO Auto-generated constructor stub
		this.nPermiso=nPermiso;
	}
	
	
	public void mostrarTaxi() {
		System.out.println("El vehiculo de placa: "+getPlaca()
		+"de modelo: " +getModelo()+"de marca: " +getMarca()
		+"cuenta con el n�mero de permiso: "+ nPermiso);
	}


	@Override
	public void desplazamiento() {
		// TODO Auto-generated method stub+
		System.out.println("Se desplaza a 30km/h");
		
	}

}
